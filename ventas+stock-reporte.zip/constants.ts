// Add export for ADMIN_ROLE
export const ADMIN_ROLE: string = 'admin'; // Placeholder value
